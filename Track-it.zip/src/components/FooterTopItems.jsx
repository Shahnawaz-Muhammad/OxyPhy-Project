export var FooterTopItems = [{}];
