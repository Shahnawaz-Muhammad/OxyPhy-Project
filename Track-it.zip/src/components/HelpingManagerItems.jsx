export const HelpingManagerItems = [
  {
    imgUrl: 'images/icon-calendar-check.svg',
    title: 'Lorem, ipsum dolor',
    desc: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit.Illo ratione at aspernatur ',
    arrowImg: 'images/right-arrow.svg',
  },
  {
    imgUrl: 'images/icon-calendar-check.svg',
    title: 'Lorem, ipsum dolor',
    desc: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit.Illo ratione at aspernatur ',
    arrowImg: 'images/right-arrow.svg',
  },
  {
    imgUrl: 'images/icon-calendar-check.svg',
    title: 'Lorem, ipsum dolor',
    desc: 'Lorem ipsum dolor, sit amet consectetur adipisicing elit.Illo ratione at aspernatur ',
    arrowImg: 'images/right-arrow.svg',
  },
];

export const HelpingManager2nd = [
  {
    imgUrl: 'images/icon-graph.svg',
    title: 'Lorem, ipsum dolor.',
  },
  {
    imgUrl: 'images/icon-graph.svg',
    title: 'Lorem, ipsum dolor.',
  },
  {
    imgUrl: 'images/icon-graph.svg',
    title: 'Lorem, ipsum dolor.',
  },
  {
    imgUrl: 'images/icon-graph.svg',
    title: 'Lorem, ipsum dolor.',
  },
  {
    imgUrl: 'images/icon-graph.svg',
    title: 'Lorem, ipsum dolor.',
  },
  {
    imgUrl: 'images/icon-graph.svg',
    title: 'Lorem, ipsum dolor.',
  },
];
