export const MenuItems = [
  {
    title: 'Home',
    url: '/',
    cName: 'nav-links',
  },
  {
    title: 'Portfolio',
    url: '#',
    cName: 'nav-links',
  },
  {
    title: 'Agency',
    url: '/pricing',
    cName: 'nav-links',
  },
  {
    title: 'Services',
    url: '#',
    cName: 'nav-links',
  },
  {
    title: 'Journal',
    url: '#',
    cName: 'nav-links',
  },
  {
    title: 'Contact',
    url: '#',
    cName: 'nav-links',
  },
  {
    title: 'Login',
    url: '/login',
    cName: 'nav-links',
  },
  {
    title: 'Signup',
    url: '#',
    cName: 'nav-links-mobile',
  },
];
