import React, { Component } from 'react';

class FooterTop extends Component {
  state = {};
  render() {
    return (
      <footer className='footer'>
        <div className='footer-top'>
          <div className='container'>
            <div className='row footer-top-row'>
              <div className='col-md-3 col-sm-6'>
                <ul className='footer-list'>
                  <li className='footer-list__item mb-3'>
                    <hi className='footer-list__item-heading'>Lorem, ipsum.</hi>
                  </li>
                  <li className='footer-list__item mb-2'>
                    <a href='$' className='footer-list__link'>
                      Lorem
                    </a>
                  </li>
                  <li className='footer-list__item mb-2'>
                    <a href='$' className='footer-list__link'>
                      Lorem
                    </a>
                  </li>
                  <li className='footer-list__item mb-2'>
                    <a href='$' className='footer-list__link'>
                      Lorem
                    </a>
                  </li>
                  <li className='footer-list__item mb-2'>
                    <a href='$' className='footer-list__link'>
                      Lorem
                    </a>
                  </li>
                </ul>
              </div>
              <div className='col-md-3 col-sm-6'>
                <ul className='footer-list'>
                  <li className='footer-list__item mb-3'>
                    <hi className='footer-list__item-heading'>Lorem, ipsum.</hi>
                  </li>
                  <li className='footer-list__item mb-2'>
                    <a href='$' className='footer-list__link'>
                      Lorem
                    </a>
                  </li>
                  <li className='footer-list__item mb-2'>
                    <a href='$' className='footer-list__link'>
                      Lorem
                    </a>
                  </li>
                  <li className='footer-list__item mb-2'>
                    <a href='$' className='footer-list__link'>
                      Lorem
                    </a>
                  </li>
                  <li className='footer-list__item mb-2'>
                    <a href='$' className='footer-list__link'>
                      Lorem
                    </a>
                  </li>
                </ul>
              </div>
              <div className='col-md-3 col-sm-6'>
                <ul className='footer-list'>
                  <li className='footer-list__item mb-3'>
                    <hi className='footer-list__item-heading'>Lorem, ipsum.</hi>
                  </li>
                  <li className='footer-list__item mb-2'>
                    <a href='$' className='footer-list__link'>
                      Lorem
                    </a>
                  </li>
                  <li className='footer-list__item mb-2'>
                    <a href='$' className='footer-list__link'>
                      Lorem
                    </a>
                  </li>
                  <li className='footer-list__item mb-2'>
                    <a href='$' className='footer-list__link'>
                      Lorem
                    </a>
                  </li>
                  <li className='footer-list__item mb-2'>
                    <a href='$' className='footer-list__link'>
                      Lorem
                    </a>
                  </li>
                </ul>
              </div>
              <div className='col-md-3 col-sm-6'>
                <ul className='footer-list'>
                  <li className='footer-list__item mb-3'>
                    <hi className='footer-list__item-heading'>Lorem, ipsum.</hi>
                  </li>
                  <li className='footer-list__item mb-2'>
                    <a href='$' className='footer-list__link'>
                      Lorem
                    </a>
                  </li>
                  <li className='footer-list__item mb-2'>
                    <a href='$' className='footer-list__link'>
                      Lorem
                    </a>
                  </li>
                  <li className='footer-list__item mb-2'>
                    <a href='$' className='footer-list__link'>
                      Lorem
                    </a>
                  </li>
                  <li className='footer-list__item mb-2'>
                    <a href='$' className='footer-list__link'>
                      Lorem
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </footer>
    );
  }
}

export default FooterTop;
