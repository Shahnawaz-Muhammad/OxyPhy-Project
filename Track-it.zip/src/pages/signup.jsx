import React, { Component } from 'react';

class Signup extends Component {
  state = {};
  render() {
    return <div>Signup</div>;
  }
}

export default Signup;
